-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 05 Şub 2021, 12:36:14
-- Sunucu sürümü: 10.4.17-MariaDB
-- PHP Sürümü: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ogr_takip_portali`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bolumler`
--

CREATE TABLE `bolumler` (
  `bolumno` int(11) NOT NULL,
  `bolumadi` varchar(100) DEFAULT NULL,
  `Fakulteno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `bolumler`
--

INSERT INTO `bolumler` (`bolumno`, `bolumadi`, `Fakulteno`) VALUES
(1, 'Bilgisayar Mühendisligi', 1),
(2, 'Bilisim Sistemleri Mühendisligi(SUNY)', 1),
(3, 'Bilgi Teknolojileri Tezsiz Yüksek Lisans', 1),
(4, 'Bilgisayar Mühendisligi Yüksek Lisans ve Doktora', 1),
(5, 'Elektrik Mühendisligi', 2),
(6, 'Elektronik ve Haberlesme Mühendisligi', 2),
(7, 'Kontrol ve Otomasyon Mühendisligi', 2),
(8, 'Elektrik Mühendisligi', 2),
(9, 'Elektronik Mühendisligi', 2),
(10, 'Telekomünikasyon Mühendisligi', 2),
(11, 'Kontrol ve Otomasyon Mühendisligi', 2),
(12, 'Biyomedikal Mühendisligi (YL)', 2),
(13, 'Gemi Insaati ve Gemi Makineleri Mühendisligi', 3),
(14, 'Gemi-DEniz Teknolojisi Mühendisligi', 3),
(15, 'Uçak Mühendisligi', 4),
(16, 'Uzay Mühendisligi', 4),
(17, 'Meteoroloji Mühendisligi', 4),
(18, 'Kontrol ve Otomasyon Mühendisligi', 4),
(19, 'Ucak ve Uzay Mühendisligi Disiplinlerarasi Lisansüstü Programi', 4),
(20, 'Atmosfer Bilimleri Lisansüstü Programi', 4),
(21, 'Kimya Mühendisligi Bolümü', 5),
(22, 'Metalurji ve Malzeme Mühendisligi Bölümü', 5),
(23, 'Gida Mühendisligi Bölümü', 5),
(24, 'Biyomühendislik Programi', 5),
(25, 'Kimya Mühendisligi Yüksek Lisans', 5),
(26, 'Kimya Mühendisligi Doktora Programi', 5),
(27, 'Malzeme Mühendisligi Yüksek Lisans Programi', 5),
(28, 'Üretim Metalurjisi ve Teknolojileri Yüksek Lisans Programi', 5),
(29, 'Seramik Mühendisligi Yüksek Lisans Programi', 5),
(30, 'Metalurji ve Malzeme Mühendisligi Doktora Programi', 5),
(31, 'Gida Mühendisligi Bölümü', 5),
(32, 'Biyomühendislik Programi', 5),
(33, 'Antropoloji Bölümü', 6),
(34, 'Arkeoloji Bölümü', 6),
(35, 'Bati Dilleri ve Edebiyatlari Bölümü', 6),
(36, 'Bilgi ve Belge Yönetimi Bölümü', 6),
(37, 'Cografya Bölümü', 6),
(38, 'Ça?da? Türk Lehçeleri ve Edebiyatlar? Bölümü', 6),
(39, 'Dilbilim Bölümü', 6),
(40, 'Do?u Dilleri ve Edebiyatlar? Bölümü', 6),
(41, 'Eskiça? Dilleri ve Kültürleri Bölümü', 6),
(42, 'Felsefe Bölümü', 6),
(43, 'Halkbilim Bölümü', 6),
(44, 'Kafkas Dilleri ve Kültürleri Bölümü', 6),
(45, 'Psikoloji Bölümü', 6),
(46, 'Sanat Tarihi Bölümü', 6),
(47, 'Astronomi ve Uzay Bilimleri', 7),
(48, 'Biyoloji', 7),
(49, 'Fizik', 7),
(50, '?statistik', 7),
(51, 'Kimya', 7),
(52, 'Matematik', 7),
(53, 'Özel Hukuk Bölümü Avrupa Birli?i Hukuku Anabilim Dal?', 8),
(54, 'Özel Hukuk Bölümü  Deniz Hukuku Anabilim Dal?', 8),
(55, 'Özel Hukuk Bölümü Is ve Sosyal Guvenlik Hukuku Anabilim Dali', 8),
(56, 'Özel Hukuk Bölümü Karsilastirmali Hukuk Anabilim Dali', 8),
(57, 'Özel Hukuk Bölümü Medeni Üsul ve Icra Iflas Hukuku Anabilim Dali', 8),
(58, 'Özel Hukuk Bölümü Medeni Hukuk Anabilim Dali', 8),
(59, 'Özel Hukuk Bölümü Roma Hukuku Anabilim Dali', 8),
(60, 'Özel Hukuk Bölümü Ticaret Hukuku Anabilim Dali', 8),
(61, 'Özel Hukuk Bölümü Milletlerarasi Özel Hukuk Anabilim Dali', 8),
(62, 'Kamu Hukuku Bölümü Anayasa Hukuku Anabilim Dali', 8),
(63, 'Kamu Hukuku Bölümü Ceza ve Ceza Muhakemesi Hukuku Anabilim Dali', 8),
(64, 'Kamu Hukuku Bölümü Genel Kamu Hukuku Anabilim Dali', 8),
(65, 'Kamu Hukuku Bölümü Hukuk Felsefesi ve Sosyolojisi Anabilim Dali', 8),
(66, 'Kamu Hukuku Bölümü Hukuk Tarihi Anabilim Dali', 8),
(67, 'Kamu Hukuku Bölümü Idari Hukuk Anabilim Dali', 8),
(68, 'Kamu Hukuku Bölümü Mali Hukuk Anabilim Dali', 8),
(69, 'Kamu Hukuku Bölümü Milletlerarasi Hukuk Anabilim Dali', 8),
(70, 'Bilgisayar Mühendisligi', 9),
(71, 'Biyomedikal Mühendisligi', 9),
(72, 'Elektrik-Elektronik Mühendisligi', 9),
(73, 'Enerji ve Malzeme Mühendisligi', 9),
(74, 'Fizik Mühendisligi', 9),
(75, 'Gida Mühendisligi', 9),
(76, 'Jeofizik Mühendisligi', 9),
(77, 'Jeoloji Mühendisligi', 9),
(78, 'Kimya Mühendisligi', 9),
(79, 'Beslenme ve Diyetetik Bölümü', 10),
(80, 'Cocuk Gelisimi Bölümü', 10),
(81, 'Ebelik bölümü', 10),
(82, 'Hemsirelik Bölümü', 10),
(83, 'Odyoloji Bölümü', 10),
(84, 'Saglik Yönetimi Bölümü', 10),
(85, 'Sosyal Hizmet Bölümü', 10),
(86, 'Moda Tasarimi', 11),
(87, 'Deniz ve liman Isletmeciligi', 12),
(88, 'Muhasebe ve vergi', 12),
(89, 'Bilgisayar Teknolojileri', 12),
(90, 'Motorlu Araclar ve Ulastirma Teknolojileri', 12),
(91, 'Bilgisayar Programciligi U.E.', 13),
(100, 'Oyun Programlama', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dersler`
--

CREATE TABLE `dersler` (
  `Dersno` int(11) NOT NULL,
  `dersadi` char(30) CHARACTER SET utf8 DEFAULT NULL,
  `bolumno` int(11) NOT NULL,
  `teorikkredi` int(11) DEFAULT NULL,
  `uygulamakredi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `dersler`
--

INSERT INTO `dersler` (`Dersno`, `dersadi`, `bolumno`, `teorikkredi`, `uygulamakredi`) VALUES
(1, 'Bicimsel Diller ve Otom3', 1, 4, 5),
(2, 'Advanced Data Structures', 1, 3, 4),
(3, 'Numerical Methods', 1, 3, 5),
(4, 'Mikrobilgisayar Laboratuvari', 1, 3, 4),
(5, 'Türk Dili I', 1, 4, 5),
(6, 'Veritabani Yönetim Sistemleri', 1, 3, 4),
(7, 'Elektronige Giris Lab.', 1, 3, 5),
(8, 'Muhendislik ve Fen Bilimleri I', 1, 3, 4),
(9, 'Orta Duzey Programlama', 1, 4, 5),
(10, 'Mantik ve Ayrik Matematik', 1, 3, 4),
(11, 'Muhendislik ve Fen Bilimleri I', 1, 5, 5),
(12, 'Muhendislik ve Fen Bilimleri I', 1, 6, 4),
(13, 'Akademik Beceri Odakli Ingiliz', 1, 5, 5),
(14, 'Akademik Beceri Odakli Ingiliz', 1, 5, 4),
(15, 'Veri Yapilari ve Algoritmalar	', 1, 5, 5),
(16, 'Bilgisayar Mimarisi', 1, 5, 4),
(17, 'Fizik I', 8, 4, 5),
(18, 'Int to Comp and Inf Systems', 8, 3, 2),
(19, 'Numerical Methods', 8, 2, 5),
(20, 'Lineer Cebir ve Uygulamaları', 8, 4, 4),
(21, 'Türk Dili I', 8, 4, 2),
(22, 'Mathematics I', 8, 3, 2),
(23, 'Elektrik Mühendisliği ve Etik	', 8, 3, 5),
(24, 'Int to Sci.&Eng.Comp. (Pyton)', 8, 3, 4),
(25, 'Probability and Statistics	', 8, 4, 5),
(26, ' 3.yy Elective Course (ITB)', 8, 3, 4),
(27, 'Signals and Systems', 8, 2, 5),
(28, 'Enerji İletim Sistemleri', 8, 2, 4),
(29, 'Muhendislikte Cizim ve Tasarim', 8, 5, 5),
(30, 'Otomatik Kontrol Sistemleri', 8, 5, 4),
(31, ' 8.yy Elective Course', 8, 5, 5),
(32, 'Elektrik Enerjisi Uretimi', 8, 5, 4),
(33, 'Veri Yapilari	', 6, 4, 5),
(34, 'Isaretler ve Sistemler', 6, 3, 2),
(35, 'Sayisal Yöntemler', 6, 2, 5),
(36, 'Mikrodalga Mühendisligi', 6, 4, 4),
(37, 'Elektromagnetik Dalgalar', 6, 4, 2),
(38, 'Analog Haberlesme	', 6, 3, 2),
(39, 'Devre ve Sistem Analizi	', 6, 3, 5),
(40, 'Elektronik I', 6, 3, 4),
(41, 'Elektronik II', 6, 4, 5),
(42, ' Intr to Sci&Eng Comp (C)', 6, 3, 4),
(43, 'Signals and Systems', 6, 2, 5),
(44, 'Diferansiyel Denklemler', 6, 2, 4),
(45, 'Muhendislik Etigi', 6, 5, 5),
(46, 'Elk. ve Hab. Müh. Giriş', 6, 5, 4),
(47, ' Genel Kimya I', 6, 5, 5),
(48, 'English Course I', 6, 5, 4),
(49, 'Türk Dili 1', 91, 2, 4),
(50, 'Türk Dili 2', 91, 3, 4),
(51, 'Girisimcilik ve Inovasyon', 91, 3, 4),
(52, 'Atatürk Ilkeleri ve Inkilap Ta', 91, 2, 3),
(53, 'Veri Tabani ve Yönetimi', 91, 2, 4),
(54, 'Ag Temelleri', 91, 3, 4),
(55, 'Arastirma Yöntem ve Teknikleri', 91, 3, 4),
(56, 'Programlama 1', 91, 2, 3),
(57, 'Programlama 2', 91, 2, 4),
(58, 'Mikro bilgisayar', 91, 3, 4),
(59, 'Ağ ve Sistem Güvenligi', 91, 3, 4),
(60, 'Web Projesi Yönetimi', 91, 2, 3),
(61, 'Veri Tabani ve Yönetimi Sistem', 91, 2, 4),
(62, 'Programlama 3', 91, 3, 4),
(63, 'Java Programlama', 91, 3, 4),
(64, 'Sistem Analizi', 91, 2, 3),
(65, 'Web Programlama', 91, 2, 3),
(66, 'Web Programlama 2', 91, 2, 3),
(67, 'Grafik ve Animasyon', 91, 2, 3),
(68, 'Mobil Programlama', 91, 2, 3),
(69, 'Açık Kaynak Kodlu Yazılım', 91, 2, 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `fakulteler`
--

CREATE TABLE `fakulteler` (
  `Fakulteno` int(11) NOT NULL,
  `fakulteadi` char(55) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `fakulteler`
--

INSERT INTO `fakulteler` (`Fakulteno`, `fakulteadi`) VALUES
(1, 'İTU Bilgisayar ve Bilisim Fakültesi'),
(2, 'İTU Elektrik Elektronik Mühendisligi'),
(3, 'İTU Gemi İnsaati ve Deniz Bilimleri Fakültesi'),
(4, 'İTU Ucak ve Uzay Bilimleri Fakültesi'),
(5, 'İTU Kimya Metalurji Mühendisliği Fakültesi'),
(6, 'Ankara Üniversitesi Dil ve Tarih-Coğrafya Fakültesi'),
(7, 'Ankara Üniversitesi Fen Fakültesi'),
(8, 'Ankara Üniversitesi Hukuk Fakültesi'),
(9, 'Ankara Üniversitesi Mühendislik Fakültesi'),
(10, 'Ankara Üniversitesi Sağlık Bilimleri Fakültesi'),
(11, 'Afyon Kocatepe Üniversitesi Dinar Meslek Yüksek Okulu'),
(12, 'Bartın Üniversitesi Meslek Yüksek Okulu'),
(13, 'Ankara Universitesi Elmadag Meslek Yüksekokulu Bilgisay');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `giris`
--

CREATE TABLE `giris` (
  `id` int(10) UNSIGNED NOT NULL,
  `kullanici_adi` varchar(50) DEFAULT NULL,
  `sifre` varchar(50) NOT NULL,
  `yetki` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `giris`
--

INSERT INTO `giris` (`id`, `kullanici_adi`, `sifre`, `yetki`) VALUES
(1, 'mkabar', 'd2ca0901256bad4b46418a07d94451f2', 'yönetici');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ilkortaokul`
--

CREATE TABLE `ilkortaokul` (
  `ilkortano` int(10) UNSIGNED NOT NULL,
  `ilkortaadi` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ilkortaokul`
--

INSERT INTO `ilkortaokul` (`ilkortano`, `ilkortaadi`) VALUES
(1, 'Gazi Osman Pasa I.Ö.O'),
(2, 'Gazi Osman Pasa Orta Okulu'),
(3, 'Yahyalar Durali Bezci ?.Ö.O'),
(4, 'Yahyalar Durali Bezci Orta Okulu'),
(5, 'Caglar ?.Ö.O'),
(6, 'Caglar Orta Okulu');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ilkortaokuldersleri`
--

CREATE TABLE `ilkortaokuldersleri` (
  `ilkortano` int(11) DEFAULT NULL,
  `ilkortadersno` int(11) NOT NULL,
  `ilkortaadi` varchar(100) DEFAULT NULL,
  `ilkortadersi` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ilkortaokuldersleri`
--

INSERT INTO `ilkortaokuldersleri` (`ilkortano`, `ilkortadersno`, `ilkortaadi`, `ilkortadersi`) VALUES
(1, 1, 'Gazi Osman Pasa ?.Ö.O', 'Türkce'),
(1, 2, 'Gazi Osman Pasa ?.Ö.O', 'Hayat Bilgisi'),
(1, 3, 'Gazi Osman Pasa ?.Ö.O', 'Matematik'),
(1, 4, 'Gazi Osman Pasa ?.Ö.O', 'Müzik'),
(1, 5, 'Gazi Osman Pasa ?.Ö.O', 'Beden Egitimi'),
(1, 6, 'Gazi Osman Pasa ?.Ö.O', 'Fen Bilimleri'),
(1, 7, 'Gazi Osman Pasa ?.Ö.O', 'Oyun ve Fizikî Etkinlikler'),
(1, 8, 'Gazi Osman Pasa ?.Ö.O', 'Sosyal Bilgiler '),
(1, 9, 'Gazi Osman Pasa ?.Ö.O', 'Yabanc? Dil'),
(3, 10, 'Yahyalar Durali Bezci ?.Ö.O', 'T.C. ?nk?lâp Tarihi ve Atatürkçülük '),
(3, 11, 'Yahyalar Durali Bezci ?.Ö.O', 'Türkce'),
(3, 12, 'Yahyalar Durali Bezci ?.Ö.O', 'Hayat Bilgisi'),
(3, 13, 'Yahyalar Durali Bezci ?.Ö.O', 'Matematik'),
(3, 14, 'Yahyalar Durali Bezci ?.Ö.O', 'Müzik'),
(3, 15, 'Yahyalar Durali Bezci ?.Ö.O', 'Beden Egitimi'),
(3, 16, 'Yahyalar Durali Bezci ?.Ö.O', 'Fen Bilimleri'),
(3, 17, 'Yahyalar Durali Bezci ?.Ö.O', 'Oyun ve Fizikî Etkinlikler'),
(3, 18, 'Yahyalar Durali Bezci ?.Ö.O', 'Sosyal Bilgiler '),
(3, 19, 'Yahyalar Durali Bezci ?.Ö.O', 'Yabanc? Dil'),
(3, 20, 'Yahyalar Durali Bezci ?.Ö.O', 'Kur’an-? Kerim'),
(5, 21, 'Caglar ?.Ö.O', 'T.C. ?nk?lâp Tarihi ve Atatürkcülük '),
(5, 22, 'Caglar ?.Ö.O', 'Türkce'),
(5, 23, 'Caglar ?.Ö.O', 'Hayat Bilgisi'),
(5, 24, 'Caglar ?.Ö.O', 'Matematik'),
(5, 25, 'Caglar ?.Ö.O', 'Müzik'),
(5, 26, 'Caglar ?.Ö.O', 'Beden Egitimi'),
(5, 27, 'Caglar ?.Ö.O', 'Fen Bilimleri'),
(5, 28, 'Caglar ?.Ö.O', 'Oyun ve Fizikî Etkinlikler'),
(5, 29, 'Caglar ?.Ö.O', 'Sosyal Bilgiler '),
(5, 30, 'Caglar ?.Ö.O', 'Yabanc? Dil'),
(5, 31, 'Caglar ?.Ö.O', 'Kur’an-i Kerim'),
(5, 32, 'Caglar ?.Ö.O', 'Hz. Muhammed’in Hayati'),
(2, 33, 'Gazi Osman Pasa Orta Okulu', 'T.C. ?nk?lâp Tarihi ve Atatürkcülük '),
(2, 34, 'Gazi Osman Pasa Orta Okulu', 'Türkce'),
(2, 35, 'Gazi Osman Pasa Orta Okulu', 'Matematik'),
(2, 36, 'Gazi Osman Pasa Orta Okulu', 'Beden Egitimi'),
(2, 37, 'Gazi Osman Pasa Orta Okulu', 'Fen Bilimleri'),
(2, 38, 'Gazi Osman Pasa Orta Okulu', 'Sosyal Bilgiler'),
(2, 39, 'Gazi Osman Pasa Orta Okulu', 'Yabanci Dil'),
(2, 40, 'Gazi Osman Pasa Orta Okulu', 'Kur’an-i Kerim'),
(2, 41, 'Gazi Osman Pasa Orta Okulu', 'Hz. Muhammed’in Hayati'),
(2, 42, 'Gazi Osman Pasa Orta Okulu', 'Bilisim Teknolojileri'),
(4, 43, 'Yahyalar Durali Bezci Orta Okulu', 'T.C. ?nk?lâp Tarihi ve Atatürkcülük'),
(4, 44, 'Yahyalar Durali Bezci Orta Okulu', 'Türkce'),
(4, 45, 'Yahyalar Durali Bezci Orta Okulu', 'Matematik'),
(4, 46, 'Yahyalar Durali Bezci Orta Okulu', 'Beden Egitimi'),
(4, 47, 'Yahyalar Durali Bezci Orta Okulu', 'Fen Bilimleri'),
(4, 48, 'Yahyalar Durali Bezci Orta Okulu', 'Sosyal Bilgiler'),
(4, 50, 'Yahyalar Durali Bezci Orta Okulu', 'Yabanci Dil'),
(4, 51, 'Yahyalar Durali Bezci Orta Okulu', 'Kur’an-i Kerim'),
(4, 52, 'Yahyalar Durali Bezci Orta Okulu', 'Hz. Muhammed’in Hayati'),
(4, 53, 'Yahyalar Durali Bezci Orta Okulu', 'Bilisim Teknolojileri'),
(6, 54, 'Caglar Orta Okulu', 'T.C. ?nk?lâp Tarihi ve Atatürkcülük'),
(6, 55, 'Caglar Orta Okulu', 'Türkce'),
(6, 56, 'Caglar Orta Okulu', 'Matematik'),
(6, 57, 'Caglar Orta Okulu', 'Beden Egitimi'),
(6, 58, 'Caglar Orta Okulu', 'Fen Bilimleri'),
(6, 59, 'Caglar Orta Okulu', 'Sosyal Bilgiler'),
(6, 60, 'Caglar Orta Okulu', 'Yabanci Dil'),
(6, 61, 'Caglar Orta Okulu', 'Kur’an-i Kerim'),
(6, 62, 'Caglar Orta Okulu', 'Hz. Muhammed’in Hayati'),
(6, 64, 'Caglar Orta Okulu', 'Bilisim Teknolojileri');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `liseler`
--

CREATE TABLE `liseler` (
  `liseno` int(10) UNSIGNED NOT NULL,
  `lisefakulte` varchar(40) NOT NULL,
  `lisebolum` varchar(30) DEFAULT NULL,
  `liseadi` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `liseler`
--

INSERT INTO `liseler` (`liseno`, `lisefakulte`, `lisebolum`, `liseadi`) VALUES
(1, 'Fen liseleri', '', 'Ankara Fen Lisesi'),
(2, 'Fen Liseleri', '', 'Ankara Pursaklar Fen Lisesi'),
(3, 'Fen liseleri', '', 'Ankara Fen Lisesi'),
(4, 'Fen Liseleri', '', 'Cumhuriyet Fen Lisesi'),
(5, 'Fen Liseleri', '', 'Ozkent Akbilek Fen Lisesi'),
(6, 'Fen Liseleri', '', 'Polatli Fen Lisesi'),
(7, 'Fen liseleri', '', ' Meliha Hasanali Bostan Cubuk Fen Lisesi'),
(8, 'Fen Liseleri', '', 'Hasanoglan Atatürk Fen Lisesi'),
(9, 'Fen liseleri', '', 'Yavuz Sultan Selim Fen Lisesi'),
(10, 'Fen Liseleri', '', 'Hasan Hüseyin Akdede Fen Lisesi'),
(11, 'Fen Liseleri', '', 'Mustafa Hakan Güvencer Fen Lisesi'),
(12, 'Fen Liseleri', '', 'Mehmet Dogan Fen Lisesi'),
(13, 'Sosyal Bilimler Lisesi', '', 'Ankara Türk Telekom Sosyal Bilimler Lisesi'),
(14, 'Sosyal Bilimler Lisesi', '', 'Hasan Ali Yücel Sosyal Bilimler Lisesi'),
(15, 'Sosyal Bilimler Lisesi', '', 'Hatice-Cemil Ercan Sosyal Bilimler Lisesi'),
(16, 'Sosyal Bilimler Lisesi', '', 'Sabahattin Zaim Sosyal Bilimler Lisesi'),
(17, 'Sosyal Bilimler Lisesi', '', 'Bilal Güngör Sosyal Bilimler Lisesi'),
(18, 'Anadolu Lisesi', '', 'Atatürk Anadolu Lisesi'),
(19, 'Anadolu Lisesi', '', 'Gazi Anadolu Lisesi'),
(20, 'Anadolu Lisesi', '', 'Mehmet Emin Resulzade Anadolu Lisesi'),
(21, 'Anadolu Lisesi', '', 'Dr.Binnaz Ege-Dr.Ridvan Ege Anadolu Lisesi'),
(22, 'Anadolu Lisesi', '', 'Betül Can Anadolu Lisesi'),
(23, 'Anadolu Lisesi', '', 'Ankara Atatürk Lisesi'),
(24, 'Anadolu Lisesi', '', 'Hac? Ömer Tarman Anadolu Lisesi'),
(25, 'Anadolu Lisesi', '', 'Nermin Mehmet Çekiç Anadolu Lisesi'),
(26, 'Anadolu Lisesi', '', 'Fethiye Kemal Mumcu Anadolu Lisesi'),
(27, 'Anadolu Lisesi', '', 'Ayranc? Anadolu Lisesi'),
(28, 'Anadolu Lisesi', '', 'Ümitköy Anadolu Lisesi'),
(29, 'Anadolu Lisesi', '', 'Bahçelievler Anadolu Lisesi'),
(30, 'Anadolu Lisesi', '', 'Ayhan Sümer Anadolu Lisesi'),
(31, 'Anadolu Lisesi', '', 'Mustafa Azmi Do?an Anadolu Lisesi'),
(32, 'Anadolu Lisesi', '', 'Süleyman Demirel Anadolu Lisesi'),
(33, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', 'Keçiören Anadolu SML'),
(34, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', 'Halide Edip Anadolu SML'),
(35, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', 'Prof. Dr. Ra??p Üner Anadolu SML'),
(36, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', '50.Y?l Anadolu SML'),
(37, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', 'Mustafa Kemal Anadolu SML'),
(38, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', 'Mamak Anadolu SML'),
(39, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', 'Pursaklar Yahya Kemal ve M.Sönmez Anadolu SML'),
(40, 'Sa?l?k Meslek Lisesi', 'Anestezi,112 Acil,Hem?irelik', 'Nefise Andiçen Anadolu SML'),
(41, 'Mesleki Teknik Anadolu Lisesi ', 'Bili?im Teknolojileri,Elektrik', 'Yenimahalle Mesleki Teknik Anadolu Lisesi'),
(42, 'Mesleki Teknik Anadolu Lisesi', 'Metal Teknolojileri,Bilisim Te', 'Cigdemtepe Mesleki Teknik Anadolu Lisesi');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `lise_dersler`
--

CREATE TABLE `lise_dersler` (
  `dersno` int(10) UNSIGNED NOT NULL,
  `liseno` int(11) NOT NULL,
  `lisedersleri` varchar(40) NOT NULL,
  `lisebölüm` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `lise_dersler`
--

INSERT INTO `lise_dersler` (`dersno`, `liseno`, `lisedersleri`, `lisebölüm`) VALUES
(1, 1, 'ALMANCA&FRANSIZCA ', ''),
(2, 1, 'ASTRONOM?-MÜZ?K', ''),
(3, 1, 'BEDEN E??T?M?', ''),
(4, 1, 'B?YOLOJ?', ''),
(5, 1, 'CO?RAFYA', ''),
(6, 1, 'D?N KÜLTÜRÜ VE AHLAK B?LG?S? ', ''),
(7, 1, 'F?Z?K', ''),
(8, 1, '?NG?L?ZCE', ''),
(9, 1, 'K?MYA', ''),
(10, 1, 'MATEMAT?K', ''),
(11, 1, 'PROJE HAZIRLAMA ', ''),
(12, 1, 'REHBERL?K', ''),
(13, 1, 'SA?LIK B?LG?S? ', ''),
(14, 1, 'TAR?H', ''),
(15, 1, 'TÜRK D?L? VE EDEB?YATI ', ''),
(16, 13, 'BEDEN E??T?M?/GÖRSEL', ''),
(17, 13, 'D?N KÜLTÜRÜ VE AHLAK B?LG?S? ', ''),
(18, 13, 'F?Z?K', ''),
(19, 13, '?kinci Yabanc? Dil', ''),
(20, 13, 'K?MYA', ''),
(21, 13, 'MATEMAT?K', ''),
(22, 13, 'SANATLAR/MÜZ?K ', ''),
(23, 13, 'OSMANLI TÜRKÇES? ', ''),
(24, 13, 'B?R?NC? YABANCI D?L ', ''),
(25, 13, 'B?YOLOJ?', ''),
(26, 13, 'CO?RAFYA', ''),
(27, 13, 'TAR?H', ''),
(28, 13, 'TÜRK D?L? VE EDEB?YATI ', ''),
(29, 13, 'REHBERL?K VE YÖNLEND?RME ', ''),
(30, 13, 'SOSYAL B?L?M ÇALI?MALARI ', ''),
(31, 13, 'Dil Ve Anlatim', ''),
(32, 33, 'MESLEK ESASLARI VE TEKN??? ', ''),
(33, 33, 'SA?LIK E??T?M?', ''),
(34, 33, 'BULA?ICI HASTALIKLAR VE BAKIMI ', ''),
(35, 33, 'ÇOCUK SA?LI?I HASTALIKLARI VE BAKIMI ', ''),
(36, 33, 'DAH?L?YE HASTALIKLARI VE BAKIMI (UYGULAM', ''),
(37, 33, 'CERRAH? HASTALIKLARI VE BAKIMI (UYGULAMA', ''),
(38, 33, 'KADIN SA?LI?I HASTALIKLARI VE BAKIMI (UY', ''),
(39, 33, 'FELSEFE', ''),
(40, 33, 'BEDEN E??T?M?', ''),
(41, 33, 'D?L VE ANLATIM', ''),
(42, 33, 'D?N KÜLTÜRÜ VE AHLÂK B?LG?S?', ''),
(45, 41, 'FELSEFE', 'Makine Teknolojisi'),
(46, 41, 'D?L VE ANLATIM', 'Makine Teknolojisi'),
(47, 41, 'TÜRK D?L? VE EDEB?YATI', 'Makine Teknolojisi'),
(48, 41, 'TAR?H', 'Makine Teknolojisi'),
(49, 41, 'COGRAFYA', 'Makine Teknolojisi'),
(50, 41, 'MATEMAT?K', 'Makine Teknolojisi'),
(51, 41, 'D?N KÜLTÜRÜ VE AHLÂK B?LG?S?', 'Makine Teknolojisi'),
(52, 41, 'T.C.?NKILAP TAR?H? VE ATATÜRKÇÜLÜK', 'Makine Teknolojisi'),
(53, 41, 'K?MYA', 'Makine Teknolojisi'),
(54, 41, 'F?Z?K', 'Makine Teknolojisi'),
(55, 41, 'SA?LIK B?LG?S?', 'Makine Teknolojisi'),
(56, 41, 'TRAF?K VE ?LK YARDIM ', 'Makine Teknolojisi'),
(57, 41, '??LETMELERDE BECER? E??T?M?', 'Makine Teknolojisi'),
(58, 41, '?MALAT ??LEMLER?', 'Makine Teknolojisi'),
(59, 41, 'Mekanik', 'Makine Teknolojisi'),
(60, 41, 'B?LG?SAYAR DESTEKL? TASARIM VE ÜRET?M (C', 'Makine Teknolojisi'),
(61, 41, 'B?LG?SAYAR KONTROLLÜ TEZGÂHLARLA ÜRET?M(', 'Makine Teknolojisi'),
(62, 41, 'H?DROL?K PNÖMAT?K', 'Makine Teknolojisi'),
(63, 41, 'KATI MODELLEME VE AN?MASYON ', 'Makine Teknolojisi'),
(64, 41, 'SER? ÜRET?M S?STEM VE MEKAN?ZMALAR', 'Makine Teknolojisi'),
(65, 41, 'HASSAS DÖKÜM MODELLEMELER? VE OTO ?N?A Y', 'Makine Teknolojisi'),
(66, 41, '?? GÜVENL???', 'Makine Teknolojisi'),
(67, 41, 'PROGRAMLAMA VE KONTROL', 'Makine Teknolojisi'),
(68, 41, 'Web Tasar?m? ve Programlama', 'Bili?im Teknolojileri'),
(69, 41, 'Grafik ve Animasyon', 'Bili?im Teknolojileri'),
(70, 41, '?nternet Programc?l???', 'Bili?im Teknolojileri'),
(71, 41, 'Veritaban? Organizasyonu', 'Bili?im Teknolojileri'),
(72, 41, 'A? Sistemleri ve Yönlendirme', 'Bili?im Teknolojileri'),
(73, 41, 'Sunucu Isletim Sistemleri', 'Bili?im Teknolojileri'),
(74, 41, 'Bilgisayarl? Devre Tasar?m? ', 'Bili?im Teknolojileri'),
(75, 41, 'Nesne Tabanl? Programlama', 'Bili?im Teknolojileri'),
(76, 41, 'Elektronik Uygulamalar?', 'Bili?im Teknolojileri'),
(77, 41, 'Tarih', 'Bili?im Teknolojileri'),
(78, 41, 'COGRAFYA', 'Bili?im Teknolojileri'),
(79, 41, 'FELSEFE', 'Bili?im Teknolojileri'),
(80, 41, 'F?Z?K', 'Bili?im Teknolojileri'),
(81, 41, 'TÜRK D?L? VE EDEB?YATI', 'Bili?im Teknolojileri'),
(82, 41, 'K?MYA', 'Bili?im Teknolojileri'),
(83, 41, 'Dil ve Anlatim', 'Bili?im Teknolojileri'),
(84, 41, 'D?N KÜLTÜRÜ VE AHLÂK B?LG?S?', 'Bili?im Teknolojileri'),
(85, 41, 'FELSEFE', 'Bili?im Teknolojileri'),
(86, 41, 'YABANCI DIL', 'Bili?im Teknolojileri'),
(87, 41, 'MESLEKI YABANCI DIL', 'Bili?im Teknolojileri'),
(88, 41, '??letmelerde Beceri E?itimi', 'Bili?im Teknolojileri'),
(89, 41, 'E-Posta Sunucu', 'Bili?im Teknolojileri'),
(90, 42, 'Web Tasar?m? ve Programlama', 'Bili?im Teknolojileri'),
(91, 42, 'Grafik ve Animasyon', 'Bili?im Teknolojileri'),
(92, 42, '?nternet Programc?l???', 'Bili?im Teknolojileri'),
(93, 42, 'Veritaban? Organizasyonu', 'Bili?im Teknolojileri'),
(94, 42, 'A? Sistemleri ve Yönlendirme', 'Bili?im Teknolojileri'),
(95, 42, 'Sunucu Isletim Sistemleri', 'Bili?im Teknolojileri'),
(96, 42, 'Bilgisayarl? Devre Tasar?m? ', 'Bili?im Teknolojileri'),
(97, 42, 'Nesne Tabanl? Programlama', 'Bili?im Teknolojileri'),
(98, 42, 'Elektronik Uygulamalar?', 'Bili?im Teknolojileri'),
(99, 42, 'Tarih', 'Bili?im Teknolojileri'),
(100, 42, 'COGRAFYA', 'Bili?im Teknolojileri'),
(101, 42, 'FELSEFE', 'Bili?im Teknolojileri'),
(102, 42, 'F?Z?K', 'Bili?im Teknolojileri'),
(103, 42, 'TÜRK D?L? VE EDEB?YATI', 'Bili?im Teknolojileri'),
(104, 42, 'K?MYA', 'Bili?im Teknolojileri'),
(105, 42, 'Dil ve Anlatim', 'Bili?im Teknolojileri'),
(106, 42, 'D?N KÜLTÜRÜ VE AHLÂK B?LG?S?', 'Bili?im Teknolojileri'),
(107, 42, 'FELSEFE', 'Bili?im Teknolojileri'),
(108, 42, 'YABANCI DIL', 'Bili?im Teknolojileri'),
(109, 42, 'MESLEKI YABANCI DIL', 'Bili?im Teknolojileri'),
(110, 42, '??letmelerde Beceri E?itimi', 'Bili?im Teknolojileri'),
(111, 42, 'E-Posta Sunucu', 'Bili?im Teknolojileri'),
(112, 41, 'TÜRK D?L? VE EDEB?YATI', 'Elektrik_Eletronik Teknolojisi'),
(113, 41, 'Dil ve Anlatim', 'Elektrik_Eletronik Teknolojisi'),
(114, 41, 'D?N KÜLTÜRÜ VE AHLÂK B?LG?S?', 'Elektrik_Eletronik Teknolojisi'),
(115, 41, 'FELSEFE', 'Elektrik_Eletronik Teknolojisi'),
(116, 41, 'Fizik', 'Elektrik_Eletronik Teknolojisi'),
(117, 41, 'COGRAFYA', 'Elektrik_Eletronik Teknolojisi'),
(118, 41, 'Kimya', 'Elektrik_Eletronik Teknolojisi'),
(119, 41, 'Matematik', 'Elektrik_Eletronik Teknolojisi'),
(120, 41, 'TAR?H', 'Elektrik_Eletronik Teknolojisi'),
(121, 41, 'SA?LIK Bilgisi', 'Elektrik_Eletronik Teknolojisi'),
(122, 41, 'MESLEKI YABANCI DIL', 'Elektrik_Eletronik Teknolojisi'),
(123, 41, 'Trafo Sar?m? ', 'Elektrik_Eletronik Teknolojisi'),
(124, 41, 'Dc Motor Sar?m Teknikleri', 'Elektrik_Eletronik Teknolojisi'),
(125, 41, 'Yazar Kasa ve Para Sayma Makinesi ', 'Elektrik_Eletronik Teknolojisi'),
(126, 41, 'Endüstriyel Kontrol ve Ar?za Analizi', 'Elektrik_Eletronik Teknolojisi'),
(127, 41, 'Bilgisayar Destekli Uygulamalar', 'Elektrik_Eletronik Teknolojisi'),
(128, 41, 'Mikrodenetleyiciler', 'Elektrik_Eletronik Teknolojisi'),
(129, 41, 'So?utucular ve Klimalar ', 'Elektrik_Eletronik Teknolojisi'),
(130, 41, 'Ak?ll? Ev Aletleri', 'Elektrik_Eletronik Teknolojisi'),
(131, 41, 'Elektronik Sistemler', 'Elektrik_Eletronik Teknolojisi'),
(132, 41, '??letmelerde Beceri E?itimi ', 'Elektrik_Eletronik Teknolojisi'),
(133, 42, 'TÜRK D?L? VE EDEB?YATI', 'Elektrik_Eletronik Teknolojisi'),
(134, 42, 'Dil ve Anlatim', 'Elektrik_Eletronik Teknolojisi'),
(135, 42, 'D?N KÜLTÜRÜ VE AHLÂK B?LG?S?', 'Elektrik_Eletronik Teknolojisi'),
(136, 42, 'FELSEFE', 'Elektrik_Eletronik Teknolojisi'),
(137, 42, 'Fizik', 'Elektrik_Eletronik Teknolojisi'),
(138, 42, 'COGRAFYA', 'Elektrik_Eletronik Teknolojisi'),
(139, 42, 'Kimya', 'Elektrik_Eletronik Teknolojisi'),
(140, 42, 'Matematik', 'Elektrik_Eletronik Teknolojisi'),
(141, 42, 'TAR?H', 'Elektrik_Eletronik Teknolojisi'),
(142, 42, 'SA?LIK Bilgisi', 'Elektrik_Eletronik Teknolojisi'),
(143, 42, 'MESLEKI YABANCI DIL', 'Elektrik_Eletronik Teknolojisi'),
(144, 42, 'Trafo Sar?m? ', 'Elektrik_Eletronik Teknolojisi'),
(145, 42, 'Dc Motor Sar?m Teknikleri', 'Elektrik_Eletronik Teknolojisi'),
(146, 42, 'Yazar Kasa ve Para Sayma Makinesi ', 'Elektrik_Eletronik Teknolojisi'),
(147, 42, 'Endüstriyel Kontrol ve Ar?za Analizi', 'Elektrik_Eletronik Teknolojisi'),
(148, 42, 'Bilgisayar Destekli Uygulamalar', 'Elektrik_Eletronik Teknolojisi'),
(149, 42, 'Mikrodenetleyiciler', 'Elektrik_Eletronik Teknolojisi'),
(150, 42, 'So?utucular ve Klimalar ', 'Elektrik_Eletronik Teknolojisi'),
(151, 42, 'Ak?ll? Ev Aletleri', 'Elektrik_Eletronik Teknolojisi'),
(152, 42, 'Elektronik Sistemler', 'Elektrik_Eletronik Teknolojisi'),
(153, 42, '??letmelerde Beceri E?itimi ', 'Elektrik_Eletronik Teknolojisi'),
(154, 41, '??letmelerde Beceri E?itimi', 'Mobilya ve iç mekan tasar?m?'),
(155, 41, 'Bilgisayarl? ?ç Mekân Resmi', 'Mobilya ve iç mekan tasar?m?'),
(156, 41, 'Bilgisayarl? ?ç Mekân Tasar?m?', 'Mobilya ve iç mekan tasar?m?'),
(157, 41, 'Mobilya Kakma ve Oyma Teknikleri', 'Mobilya ve iç mekan tasar?m?'),
(158, 41, 'Mobilya Tornalama Teknikleri', 'Mobilya ve iç mekan tasar?m?'),
(159, 41, 'Mobilya Süsleme Resmi', 'Mobilya ve iç mekan tasar?m?'),
(160, 41, 'Mobilya ?skelet ve Dö?eme Teknikleri ', 'Mobilya ve iç mekan tasar?m?'),
(161, 41, '?ç Mekân Do?ramalar?', 'Mobilya ve iç mekan tasar?m?'),
(162, 41, 'D?? Mekân Do?ramalar?', 'Mobilya ve iç mekan tasar?m?'),
(163, 41, 'Bilgisayarla D?? Mekân Do?rama Resmi', 'Mobilya ve iç mekan tasar?m?'),
(164, 41, 'FELSEFE', 'Mobilya ve iç mekan tasar?m?'),
(165, 41, 'Fizik', 'Mobilya ve iç mekan tasar?m?'),
(166, 41, 'Kimya', 'Mobilya ve iç mekan tasar?m?'),
(167, 41, 'MATEMAT?K', 'Mobilya ve iç mekan tasar?m?'),
(168, 41, 'DIL ve Anlatim', 'Mobilya ve iç mekan tasar?m?'),
(169, 41, 'Cografya', 'Mobilya ve iç mekan tasar?m?'),
(170, 41, 'Trafik ve ilk yard?m', 'Mobilya ve iç mekan tasar?m?'),
(171, 41, 'Türk EDEB?YATI', 'Mobilya ve iç mekan tasar?m?'),
(172, 41, 'TAR?H', 'Mobilya ve iç mekan tasar?m?'),
(173, 41, 'Sa?lik Bilgisi', 'Mobilya ve iç mekan tasar?m?'),
(174, 41, 'T.C. ?nk?lap Tarihi ve Atatürkçülük ', 'Mobilya ve iç mekan tasar?m?'),
(175, 41, 'Yabanci Dil', 'Mobilya ve iç mekan tasar?m?'),
(176, 42, 'Matematik ve Mesleki MATEMAT?K', 'Metal Teknolojileri'),
(177, 42, 'Türkce', 'Metal Teknolojileri'),
(178, 42, '??LETME B?LG?S? VE TOPLAM KAL?TE YÖNET?M', 'Metal Teknolojileri'),
(179, 42, 'D?N KÜLTÜRÜ VE MESLEK AHLAKI ', 'Metal Teknolojileri'),
(180, 42, 'MESLEK? B?LG?SAYAR ', 'Metal Teknolojileri'),
(181, 42, 'Kaynakcilik', 'Metal Teknolojileri'),
(182, 42, 'ISIL ??LEM ', 'Metal Teknolojileri'),
(183, 42, 'CEL?K KONSTRÜKS?YON', 'Metal Teknolojileri'),
(184, 42, 'METAL DO?RAMA ', 'Metal Teknolojileri'),
(185, 42, 'METAL LEVHA ??LEMEC?L???', 'Metal Teknolojileri'),
(186, 42, 'SAC ??LER?', 'Metal Teknolojileri'),
(187, 42, 'KAROSERC?L?K ', 'Metal Teknolojileri'),
(188, 42, 'AV?ZEC?L?K ', 'Metal Teknolojileri'),
(189, 42, 'Fizik', 'Metal Teknolojileri'),
(190, 42, 'Kimya', 'Metal Teknolojileri'),
(191, 42, 'Biyoloji', 'Metal Teknolojileri'),
(192, 42, 'T.C. ?nk?lap Tarihi ve Atatürkçülük', 'Metal Teknolojileri'),
(193, 42, 'Mesleki yabanci dil', 'Metal Teknolojileri'),
(194, 42, 'FELSEFE', 'Metal Teknolojileri'),
(195, 42, 'Saglik Bilgisi', 'Metal Teknolojileri'),
(196, 42, 'Trafik ve ilk yardim', 'Metal Teknolojileri'),
(197, 42, 'TEMEL METAL ?EK?LLEND?RME', 'Metal Teknolojileri'),
(198, 42, '??letmelerde Beceri E?itimi', 'Mobilya ve iç mekan tasar?m?'),
(199, 42, 'Bilgisayarl? ?ç Mekân Resmi', 'Mobilya ve iç mekan tasar?m?'),
(200, 42, 'Bilgisayarl? ?ç Mekân Tasar?m?', 'Mobilya ve iç mekan tasar?m?'),
(201, 42, 'Mobilya Kakma ve Oyma Teknikleri', 'Mobilya ve iç mekan tasar?m?'),
(202, 42, 'Mobilya Tornalama Teknikleri', 'Mobilya ve iç mekan tasar?m?'),
(203, 42, 'Mobilya Süsleme Resmi', 'Mobilya ve iç mekan tasar?m?'),
(204, 42, 'Mobilya ?skelet ve Dö?eme Teknikleri ', 'Mobilya ve iç mekan tasar?m?'),
(205, 42, '?ç Mekân Do?ramalar?', 'Mobilya ve iç mekan tasar?m?'),
(206, 42, 'D?? Mekân Do?ramalar?', 'Mobilya ve iç mekan tasar?m?'),
(207, 42, 'Bilgisayarla D?? Mekân Do?rama Resmi', 'Mobilya ve iç mekan tasar?m?'),
(208, 42, 'FELSEFE', 'Mobilya ve iç mekan tasar?m?'),
(209, 42, 'Fizik', 'Mobilya ve iç mekan tasar?m?'),
(210, 42, 'Kimya', 'Mobilya ve iç mekan tasar?m?'),
(211, 42, 'MATEMAT?K', 'Mobilya ve iç mekan tasar?m?'),
(212, 42, 'DIL ve Anlatim', 'Mobilya ve iç mekan tasar?m?'),
(213, 42, 'Cografya', 'Mobilya ve iç mekan tasar?m?'),
(214, 42, 'Trafik ve ilk yard?m', 'Mobilya ve iç mekan tasar?m?'),
(215, 42, 'Türk EDEB?YATI', 'Mobilya ve iç mekan tasar?m?'),
(216, 42, 'TAR?H', 'Mobilya ve iç mekan tasar?m?'),
(217, 42, 'Sa?lik Bilgisi', 'Mobilya ve iç mekan tasar?m?'),
(218, 42, 'T.C. ?nk?lap Tarihi ve Atatürkçülük ', 'Mobilya ve iç mekan tasar?m?'),
(219, 42, 'Yabanci Dil', 'Mobilya ve iç mekan tasar?m?\r\n'),
(221, 2, 'ALMANCA&FRANSIZCA ', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `notlar`
--

CREATE TABLE `notlar` (
  `ogrencino` int(11) NOT NULL,
  `dersno` int(11) NOT NULL,
  `vize` int(11) DEFAULT NULL,
  `final` int(11) DEFAULT NULL,
  `butunleme` int(11) DEFAULT NULL,
  `durum` char(10) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `notlar`
--

INSERT INTO `notlar` (`ogrencino`, `dersno`, `vize`, `final`, `butunleme`, `durum`) VALUES
(15330161, 2, 100, 95, 0, 'geçti'),
(15330162, 2, 25, 10, 15, 'kaldı'),
(15330163, 3, 100, 90, NULL, 'geçti'),
(15330164, 1, 50, 35, NULL, 'kaldı'),
(15330165, 1, 25, 15, 30, 'kaldı'),
(15330166, 2, 90, 100, NULL, 'geçti'),
(15330167, 2, 90, 40, 85, 'geçti'),
(15330168, 3, 9, 15, 10, 'kaldı'),
(15330169, 3, 100, 65, 0, 'geçti'),
(15330171, 3, 0, 40, 0, 'kaldi');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogrenci`
--

CREATE TABLE `ogrenci` (
  `tc_no` varchar(20) DEFAULT NULL,
  `adi` varchar(25) DEFAULT NULL,
  `soyadi` varchar(25) DEFAULT NULL,
  `anne_adi` varchar(20) DEFAULT NULL,
  `baba_adi` varchar(20) DEFAULT NULL,
  `d_yeri` varchar(25) DEFAULT NULL,
  `d_tarihi` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ogrenci`
--

INSERT INTO `ogrenci` (`tc_no`, `adi`, `soyadi`, `anne_adi`, `baba_adi`, `d_yeri`, `d_tarihi`) VALUES
('21225267961', 'Melek', 'Ünal', 'Melike', 'Murat', 'Istanbul', '1998-01-31'),
('21226287291', 'Nergis', 'Ak', 'Lale', 'Furkan', 'Ankara', '1998-09-14'),
('21241269351', 'Merve', 'Unal', 'Acelya', 'Ege', 'Istanbul', '2000-09-10'),
('21241069471', 'Mehmet', 'Un', 'Asel', 'Kadir', 'Igdir', '1998-02-18'),
('21269348155', 'Murat', 'Kanat', 'Gül', 'Talat', 'Izmir', '1998-03-30'),
('21206035297', 'Esila', 'Uzüm', 'Deniz', 'Firat', 'Izmit', '1998-04-28'),
('20256374137', 'Erdem', 'Küskanat', 'Fünda', 'Abdüllah', 'Antalya', '1998-12-12');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogrenciler`
--

CREATE TABLE `ogrenciler` (
  `ogrencino` int(11) NOT NULL,
  `ogrenciadi` char(10) CHARACTER SET utf8 DEFAULT NULL,
  `ogrencisoyadi` char(10) CHARACTER SET utf8 DEFAULT NULL,
  `cinsiyet` char(10) CHARACTER SET utf8 DEFAULT NULL,
  `dogumtarihi` varchar(150) DEFAULT NULL,
  `bolumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ogrenciler`
--

INSERT INTO `ogrenciler` (`ogrencino`, `ogrenciadi`, `ogrencisoyadi`, `cinsiyet`, `dogumtarihi`, `bolumno`) VALUES
(15330161, 'Merve', 'Ünal', 'Bayan', '1998-01-30', 1),
(15330162, 'Mehmet', 'Ün', 'Erkek', '1998-02-18', 2),
(15330163, 'Murat', 'Kanat', 'Erkek', '1998-03-30', 3),
(15330164, 'Esila', 'Üzüm', 'Bayan', '1998-04-28', 1),
(15330165, 'Erdem', 'Kuşkanat', 'Erkek', '1998-12-12', 1),
(15330166, 'Asel', 'Gül', 'Bayan', '1998-11-15', 2),
(15330167, 'Nergis', 'Ak', 'Bayan', '1998-09-14', 2),
(15330169, 'Yaren', 'Uçar', 'Bayan', '1998-01-02', 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogrencinotuhesapla`
--

CREATE TABLE `ogrencinotuhesapla` (
  `ogrencino` int(11) NOT NULL,
  `Yazili1` int(11) DEFAULT NULL,
  `Yazili2` int(11) DEFAULT NULL,
  `Performans` int(11) DEFAULT NULL,
  `Ortalama` int(11) DEFAULT NULL,
  `Durum` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ogrencinotuhesapla`
--

INSERT INTO `ogrencinotuhesapla` (`ogrencino`, `Yazili1`, `Yazili2`, `Performans`, `Ortalama`, `Durum`) VALUES
(1780, 100, 50, 40, 63, 'geçtiniz'),
(1786, 90, 50, 40, 60, 'Geçtiniz');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ortalama`
--

CREATE TABLE `ortalama` (
  `ogrencino` int(11) NOT NULL,
  `Yazili1` int(11) DEFAULT NULL,
  `Yazili2` int(11) DEFAULT NULL,
  `Performans` int(11) DEFAULT NULL,
  `Ortalama` int(11) DEFAULT NULL,
  `Notkarsiligi` int(11) DEFAULT NULL,
  `Durum` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ortalama`
--

INSERT INTO `ortalama` (`ogrencino`, `Yazili1`, `Yazili2`, `Performans`, `Ortalama`, `Notkarsiligi`, `Durum`) VALUES
(15330180, 100, 50, 60, 70, 4, 'Geçti');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uninnothesapla`
--

CREATE TABLE `uninnothesapla` (
  `ogrencino` int(11) NOT NULL,
  `vize` int(11) DEFAULT NULL,
  `final` int(11) DEFAULT NULL,
  `ortalama` int(11) DEFAULT NULL,
  `durum` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `uninnothesapla`
--

INSERT INTO `uninnothesapla` (`ogrencino`, `vize`, `final`, `ortalama`, `durum`) VALUES
(15330155, 100, 50, 60, 'Geçti'),
(15330160, 100, 70, 82, 'Geçti');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `bolumler`
--
ALTER TABLE `bolumler`
  ADD PRIMARY KEY (`bolumno`);

--
-- Tablo için indeksler `dersler`
--
ALTER TABLE `dersler`
  ADD PRIMARY KEY (`Dersno`);

--
-- Tablo için indeksler `fakulteler`
--
ALTER TABLE `fakulteler`
  ADD PRIMARY KEY (`Fakulteno`);

--
-- Tablo için indeksler `giris`
--
ALTER TABLE `giris`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ilkortaokul`
--
ALTER TABLE `ilkortaokul`
  ADD PRIMARY KEY (`ilkortano`);

--
-- Tablo için indeksler `ilkortaokuldersleri`
--
ALTER TABLE `ilkortaokuldersleri`
  ADD PRIMARY KEY (`ilkortadersno`);

--
-- Tablo için indeksler `liseler`
--
ALTER TABLE `liseler`
  ADD PRIMARY KEY (`liseno`);

--
-- Tablo için indeksler `lise_dersler`
--
ALTER TABLE `lise_dersler`
  ADD PRIMARY KEY (`dersno`);

--
-- Tablo için indeksler `notlar`
--
ALTER TABLE `notlar`
  ADD PRIMARY KEY (`ogrencino`);

--
-- Tablo için indeksler `ogrenciler`
--
ALTER TABLE `ogrenciler`
  ADD PRIMARY KEY (`ogrencino`);

--
-- Tablo için indeksler `ogrencinotuhesapla`
--
ALTER TABLE `ogrencinotuhesapla`
  ADD PRIMARY KEY (`ogrencino`);

--
-- Tablo için indeksler `ortalama`
--
ALTER TABLE `ortalama`
  ADD PRIMARY KEY (`ogrencino`);

--
-- Tablo için indeksler `uninnothesapla`
--
ALTER TABLE `uninnothesapla`
  ADD PRIMARY KEY (`ogrencino`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `giris`
--
ALTER TABLE `giris`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `ilkortaokul`
--
ALTER TABLE `ilkortaokul`
  MODIFY `ilkortano` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `liseler`
--
ALTER TABLE `liseler`
  MODIFY `liseno` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Tablo için AUTO_INCREMENT değeri `lise_dersler`
--
ALTER TABLE `lise_dersler`
  MODIFY `dersno` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
