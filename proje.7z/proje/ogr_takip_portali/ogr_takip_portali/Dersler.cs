﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ogr_takip_portali
{
    public partial class Dersler : Form
    {
        public Dersler()
        {
            InitializeComponent();
        }
        MySqlConnection baglanti = new MySqlConnection("Server=localhost; Database=ogr_takip_portali; uid=root; Password= ;");
        DataTable tablo = new DataTable();
         private void Dersler_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlDataAdapter adaptor = new MySqlDataAdapter("select * from dersler ", baglanti);
            adaptor.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("insert into dersler(Dersno,dersadi,bolumno,teorikkredi,uygulamakredi) values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("başarılı");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from dersler ", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        public void textdoldur()
        {

            try
            {
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                 }
            catch
            {


            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("delete from dersler where Dersno='" + textBox6.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Silindi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from dersler ", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("update dersler set Dersno='" + textBox1.Text + "',dersadi='" + textBox2.Text + "', bolumno='" + textBox3.Text + "',teorikkredi='" + textBox4.Text + "', uygulamakredi='" + textBox5.Text + "'  where Dersno='" + textBox6.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Değiştirildi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from dersler", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            textdoldur();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            giristablo Girisform = new giristablo();
            this.Visible = false;

            Girisform.ShowDialog();
            this.Close();
        }
    }
}
