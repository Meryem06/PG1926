﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace ogr_takip_portali
{
    public partial class acilis : Form
    {
        public acilis()
        {
            InitializeComponent();
        }
        public static string MD5Sifrele(string metin)
        {
            try
            {
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

                byte[] btr = Encoding.UTF8.GetBytes(metin);
                btr = md5.ComputeHash(btr);
                StringBuilder sb = new StringBuilder();


                foreach (byte ba in btr)
                {
                    sb.Append(ba.ToString("x2").ToLower());

                }

                return sb.ToString();
            }
            catch (Exception)
            {

                throw;
            }
        }

        MySqlConnection baglanti = new MySqlConnection("Server=localhost; Database=ogr_takip_portali; uid=root; Password= ;");
        DataTable tablo = new DataTable();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                MySqlCommand komut = new MySqlCommand("select * from giris where kullanici_adi='" + textBox1.Text + "' and sifre='" + MD5Sifrele(textBox2.Text) + "' ", baglanti);
                komut.ExecuteNonQuery();
                MySqlDataAdapter adap = new MySqlDataAdapter("select * from giris", baglanti);
                MySqlDataReader oku = komut.ExecuteReader();
               

                if (oku.Read() == true)
                {
                    giristablo fr1 = new giristablo();
                    this.Visible = false;
                    Hide();




                   // fr1.label1.Text = textBox1.Text;
                   //fr1.label2.Text = textBox2.Text;


                    fr1.ShowDialog();
                    this.Close();

                }


                else
                {
                    MessageBox.Show("kullanıcı adı ya da şifre hatalı");
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox1.Focus();
                }
                baglanti.Close();
            }
            catch (Exception)
            {

                //throw;
            }

        }

        private void acilis_Load(object sender, EventArgs e)
        {

        }
    }
    }
    

    


