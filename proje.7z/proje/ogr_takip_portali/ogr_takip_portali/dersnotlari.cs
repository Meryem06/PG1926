﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogr_takip_portali
{
    public partial class dersnotlari : Form
    {
        public dersnotlari()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://sanalkurs.net/c-da-nesne-dizileri-ders-35-5524.html");
        }
        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://selimkaratas.com.tr/wp/java-se-ders-notlari");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://selimkaratas.com.tr/wp/adwords-egitimi");
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://selimkaratas.com.tr/wp/oracle-11g-r2-egitimi-ders-notlari");
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://hrzafer.com/sql-dersleri");
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://sibelsomyurek.com/veritabani/ders_notlari.html");
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.senolhoca.com/");
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.youtube.com/channel/UCrFuOhaISP4OMarjFR4dYBA");
        }

        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=OX44CosnXLM&list=PLBYG4UJ41bYVy5757nQxkhgolE8Fk3Ye4");
        }

        private void linkLabel10_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.cizgi-tagem.org/e-kampus-egitim/");
        }

        private void linkLabel11_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.turkceogretmeni.net/");
        }

        private void linkLabel12_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.edebiyatogretmeni.org/");
        }

        private void linkLabel13_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.turkedebiyati.org/dil-ve-anlatim-konu-anlatimi/");
        }

        private void linkLabel14_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.ossmat.com/index.php/konu-anlatm/kimya-dersi-konu-anlatimi.html");//ossmat fizik vs. derslerin konu anlatımları veya ders notları bulunmaktadır. 
        }

        private void linkLabel15_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.dersimiz.com/ders_notlari/Kimya-Ders-Notlari-45-sayfa1.html");
        }

        private void linkLabel16_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.fizikpenceresi.com/index.php/haberler/122-9-sinif-fizik-ders-notlari");
        }

        private void linkLabel18_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.yahyagungor.net/cografya-ders-notlari.html");
        }

        private void linkLabel17_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.derscalisiyorum.com.tr/genel/tarih.html");
        }
        

        private void dersnotlari_Load(object sender, EventArgs e)
        {
            //buradaki değerler properties penceresinden de ayarlanabilir.
            trackBar1.Minimum = 0;//trackbar1 en küçük değer
            trackBar1.Maximum = 100;//trackbar1 en büyük değer
            trackBar1.TickFrequency = 20;//trackbar1 de gösterilecek çizgi sayısı 
            trackBar2.Minimum = 0;//trackbar2 en küçük değer
            trackBar2.Maximum = 100;//trackbar2 en büyük değer
            trackBar2.TickFrequency = 20;//trackbar2 de gösterilecek çizgi sayısı 
        }
         private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            if (vScrollBar1.Value <= 30 && vScrollBar1.Value >= 0)
            {
                this.BackColor = Color.YellowGreen;
            }
            if (vScrollBar1.Value > 30 && vScrollBar1.Value <= 50)
            {
                this.BackColor = Color.LightPink;
            }
            if (vScrollBar1.Value > 50 && vScrollBar1.Value <= 75)
            {
                this.BackColor = Color.LightSeaGreen;
            }
            if (vScrollBar1.Value > 75 && vScrollBar1.Value < 100)
            {
                this.BackColor = Color.Salmon;
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

            //Font özelliği readonly olduğu için Font sınıfında yeni bir font tanımlandı.
            linkLabel1.Font = new Font("tahoma", trackBar1.Value);
            linkLabel2.Font = new Font("tahoma", trackBar1.Value);
            linkLabel3.Font = new Font("tahoma", trackBar1.Value);
            linkLabel4.Font = new Font("tahoma", trackBar1.Value);
            linkLabel5.Font = new Font("tahoma", trackBar1.Value);
            linkLabel6.Font = new Font("tahoma", trackBar1.Value);
            linkLabel7.Font = new Font("tahoma", trackBar1.Value);
            linkLabel8.Font = new Font("tahoma", trackBar1.Value);
            linkLabel9.Font = new Font("tahoma", trackBar1.Value);
            linkLabel10.Font = new Font("tahoma", trackBar1.Value);
            linkLabel11.Font = new Font("tahoma", trackBar1.Value);
            linkLabel12.Font = new Font("tahoma", trackBar1.Value);
            linkLabel13.Font = new Font("tahoma", trackBar1.Value);
            linkLabel14.Font = new Font("tahoma", trackBar1.Value);
            linkLabel15.Font = new Font("tahoma", trackBar1.Value);
            linkLabel16.Font = new Font("tahoma", trackBar1.Value);
            linkLabel17.Font = new Font("tahoma", trackBar1.Value);
            linkLabel18.Font = new Font("tahoma", trackBar1.Value);//trackBar1 kontrolünün değerine göre linklabel18 deki yazının boyutu değişir.

        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            linkLabel1.Font = new Font("verdana", trackBar2.Value);
            linkLabel2.Font = new Font("verdana", trackBar2.Value);
            linkLabel3.Font = new Font("verdana", trackBar2.Value);
            linkLabel4.Font = new Font("verdana", trackBar2.Value);
            linkLabel5.Font = new Font("verdana", trackBar2.Value);
            linkLabel6.Font = new Font("verdana", trackBar2.Value);
            linkLabel7.Font = new Font("verdana", trackBar2.Value);
            linkLabel8.Font = new Font("verdana", trackBar2.Value);
            linkLabel9.Font = new Font("verdana", trackBar2.Value);
            linkLabel10.Font = new Font("verdana", trackBar2.Value);
            linkLabel11.Font = new Font("verdana", trackBar2.Value);
            linkLabel12.Font = new Font("verdana", trackBar2.Value);
            linkLabel13.Font = new Font("verdana", trackBar2.Value);
            linkLabel14.Font = new Font("verdana", trackBar2.Value);
            linkLabel15.Font = new Font("verdana", trackBar2.Value);
            linkLabel16.Font = new Font("verdana", trackBar2.Value);
            linkLabel17.Font = new Font("verdana", trackBar2.Value);
            linkLabel18.Font = new Font("verdana", trackBar2.Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            giristablo Girisform = new giristablo();
            this.Visible = false;

            Girisform.ShowDialog();
            this.Close();
        }
    }
}
