﻿namespace ogr_takip_portali
{
    partial class giristablo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.yönetimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kullaniciİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eğitimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fakültelerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bölümlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.derslerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sınıfYönetimiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrencilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.okullarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.liseokulToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.liseokuldersleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ilkokulToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ilkokuldersleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notHesaplamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uninothesaplaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ortalamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.okulabaslamaayiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.okulabaslamaayiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dersnotlariToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dersnotlariToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rehberGörüsüToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rehbergörüsüToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ColumnHeadersVisible = false;
            this.dataGridView1.Location = new System.Drawing.Point(0, 200);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(691, 131);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.DataSourceChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button1.Location = new System.Drawing.Point(14, 160);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Kaydet";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(137, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(137, 59);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(137, 83);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(137, 115);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(48, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "id:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(48, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Kullanici_adi:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(48, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Sifre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(48, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Yetki:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button2.Location = new System.Drawing.Point(116, 160);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "Sil";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(197, 163);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 11;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button4.Location = new System.Drawing.Point(415, 160);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 13;
            this.button4.Text = "yenile";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yönetimToolStripMenuItem,
            this.eğitimToolStripMenuItem,
            this.sınıfYönetimiToolStripMenuItem,
            this.okullarToolStripMenuItem,
            this.notHesaplamaToolStripMenuItem,
            this.okulabaslamaayiToolStripMenuItem,
            this.dersnotlariToolStripMenuItem,
            this.rehberGörüsüToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(691, 24);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // yönetimToolStripMenuItem
            // 
            this.yönetimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kullaniciİşlemleriToolStripMenuItem});
            this.yönetimToolStripMenuItem.Name = "yönetimToolStripMenuItem";
            this.yönetimToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.yönetimToolStripMenuItem.Text = "Yönetim";
            // 
            // kullaniciİşlemleriToolStripMenuItem
            // 
            this.kullaniciİşlemleriToolStripMenuItem.Name = "kullaniciİşlemleriToolStripMenuItem";
            this.kullaniciİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.kullaniciİşlemleriToolStripMenuItem.Text = "Kullanıcı İşlemleri";
            this.kullaniciİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.kullaniciİşlemleriToolStripMenuItem_Click);
            // 
            // eğitimToolStripMenuItem
            // 
            this.eğitimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fakültelerToolStripMenuItem,
            this.bölümlerToolStripMenuItem,
            this.derslerToolStripMenuItem});
            this.eğitimToolStripMenuItem.Name = "eğitimToolStripMenuItem";
            this.eğitimToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.eğitimToolStripMenuItem.Text = "Eğitim";
            // 
            // fakültelerToolStripMenuItem
            // 
            this.fakültelerToolStripMenuItem.Name = "fakültelerToolStripMenuItem";
            this.fakültelerToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.fakültelerToolStripMenuItem.Text = "Fakülteler";
            this.fakültelerToolStripMenuItem.Click += new System.EventHandler(this.fakültelerToolStripMenuItem_Click);
            // 
            // bölümlerToolStripMenuItem
            // 
            this.bölümlerToolStripMenuItem.Name = "bölümlerToolStripMenuItem";
            this.bölümlerToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.bölümlerToolStripMenuItem.Text = "Bölümler";
            this.bölümlerToolStripMenuItem.Click += new System.EventHandler(this.bölümlerToolStripMenuItem_Click);
            // 
            // derslerToolStripMenuItem
            // 
            this.derslerToolStripMenuItem.Name = "derslerToolStripMenuItem";
            this.derslerToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.derslerToolStripMenuItem.Text = "Dersler";
            this.derslerToolStripMenuItem.Click += new System.EventHandler(this.derslerToolStripMenuItem_Click);
            // 
            // sınıfYönetimiToolStripMenuItem
            // 
            this.sınıfYönetimiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.notlarToolStripMenuItem,
            this.ogrencilerToolStripMenuItem});
            this.sınıfYönetimiToolStripMenuItem.Name = "sınıfYönetimiToolStripMenuItem";
            this.sınıfYönetimiToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.sınıfYönetimiToolStripMenuItem.Text = "Sınıf Yönetimi";
            // 
            // notlarToolStripMenuItem
            // 
            this.notlarToolStripMenuItem.Name = "notlarToolStripMenuItem";
            this.notlarToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.notlarToolStripMenuItem.Text = "Notlar";
            this.notlarToolStripMenuItem.Click += new System.EventHandler(this.notlarToolStripMenuItem_Click);
            // 
            // ogrencilerToolStripMenuItem
            // 
            this.ogrencilerToolStripMenuItem.Name = "ogrencilerToolStripMenuItem";
            this.ogrencilerToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.ogrencilerToolStripMenuItem.Text = "ogrenciler";
            this.ogrencilerToolStripMenuItem.Click += new System.EventHandler(this.ogrencilerToolStripMenuItem_Click);
            // 
            // okullarToolStripMenuItem
            // 
            this.okullarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.liseokulToolStripMenuItem,
            this.liseokuldersleriToolStripMenuItem,
            this.ilkokulToolStripMenuItem,
            this.ilkokuldersleriToolStripMenuItem});
            this.okullarToolStripMenuItem.Name = "okullarToolStripMenuItem";
            this.okullarToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.okullarToolStripMenuItem.Text = "Okullar";
            // 
            // liseokulToolStripMenuItem
            // 
            this.liseokulToolStripMenuItem.Name = "liseokulToolStripMenuItem";
            this.liseokulToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.liseokulToolStripMenuItem.Text = "liseokul";
            this.liseokulToolStripMenuItem.Click += new System.EventHandler(this.liseokulToolStripMenuItem_Click);
            // 
            // liseokuldersleriToolStripMenuItem
            // 
            this.liseokuldersleriToolStripMenuItem.Name = "liseokuldersleriToolStripMenuItem";
            this.liseokuldersleriToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.liseokuldersleriToolStripMenuItem.Text = "liseokuldersleri";
            this.liseokuldersleriToolStripMenuItem.Click += new System.EventHandler(this.liseokuldersleriToolStripMenuItem_Click);
            // 
            // ilkokulToolStripMenuItem
            // 
            this.ilkokulToolStripMenuItem.Name = "ilkokulToolStripMenuItem";
            this.ilkokulToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ilkokulToolStripMenuItem.Text = "ilkokul";
            this.ilkokulToolStripMenuItem.Click += new System.EventHandler(this.ilkokulToolStripMenuItem_Click);
            // 
            // ilkokuldersleriToolStripMenuItem
            // 
            this.ilkokuldersleriToolStripMenuItem.Name = "ilkokuldersleriToolStripMenuItem";
            this.ilkokuldersleriToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ilkokuldersleriToolStripMenuItem.Text = "ilkokuldersleri";
            this.ilkokuldersleriToolStripMenuItem.Click += new System.EventHandler(this.ilkokuldersleriToolStripMenuItem_Click);
            // 
            // notHesaplamaToolStripMenuItem
            // 
            this.notHesaplamaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ogrenciToolStripMenuItem,
            this.uninothesaplaToolStripMenuItem,
            this.ortalamaToolStripMenuItem});
            this.notHesaplamaToolStripMenuItem.Name = "notHesaplamaToolStripMenuItem";
            this.notHesaplamaToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.notHesaplamaToolStripMenuItem.Text = "Not Hesaplama";
            // 
            // ogrenciToolStripMenuItem
            // 
            this.ogrenciToolStripMenuItem.Name = "ogrenciToolStripMenuItem";
            this.ogrenciToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.ogrenciToolStripMenuItem.Text = "ogrencinotuhesapla";
            this.ogrenciToolStripMenuItem.Click += new System.EventHandler(this.ogrenciToolStripMenuItem_Click);
            // 
            // uninothesaplaToolStripMenuItem
            // 
            this.uninothesaplaToolStripMenuItem.Name = "uninothesaplaToolStripMenuItem";
            this.uninothesaplaToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.uninothesaplaToolStripMenuItem.Text = "uninothesapla";
            this.uninothesaplaToolStripMenuItem.Click += new System.EventHandler(this.uninothesaplaToolStripMenuItem_Click);
            // 
            // ortalamaToolStripMenuItem
            // 
            this.ortalamaToolStripMenuItem.Name = "ortalamaToolStripMenuItem";
            this.ortalamaToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.ortalamaToolStripMenuItem.Text = "ortalama";
            this.ortalamaToolStripMenuItem.Click += new System.EventHandler(this.ortalamaToolStripMenuItem_Click);
            // 
            // okulabaslamaayiToolStripMenuItem
            // 
            this.okulabaslamaayiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.okulabaslamaayiToolStripMenuItem1});
            this.okulabaslamaayiToolStripMenuItem.Name = "okulabaslamaayiToolStripMenuItem";
            this.okulabaslamaayiToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.okulabaslamaayiToolStripMenuItem.Text = "Anasınıfı-Ilkokul";
            // 
            // okulabaslamaayiToolStripMenuItem1
            // 
            this.okulabaslamaayiToolStripMenuItem1.Name = "okulabaslamaayiToolStripMenuItem1";
            this.okulabaslamaayiToolStripMenuItem1.Size = new System.Drawing.Size(162, 22);
            this.okulabaslamaayiToolStripMenuItem1.Text = "okulabaslamaayi";
            this.okulabaslamaayiToolStripMenuItem1.Click += new System.EventHandler(this.okulabaslamaayiToolStripMenuItem1_Click);
            // 
            // dersnotlariToolStripMenuItem
            // 
            this.dersnotlariToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dersnotlariToolStripMenuItem1});
            this.dersnotlariToolStripMenuItem.Name = "dersnotlariToolStripMenuItem";
            this.dersnotlariToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.dersnotlariToolStripMenuItem.Text = "dersnotlari";
            // 
            // dersnotlariToolStripMenuItem1
            // 
            this.dersnotlariToolStripMenuItem1.Name = "dersnotlariToolStripMenuItem1";
            this.dersnotlariToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.dersnotlariToolStripMenuItem1.Text = "dersnotlari";
            this.dersnotlariToolStripMenuItem1.Click += new System.EventHandler(this.dersnotlariToolStripMenuItem1_Click);
            // 
            // rehberGörüsüToolStripMenuItem
            // 
            this.rehberGörüsüToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rehbergörüsüToolStripMenuItem1});
            this.rehberGörüsüToolStripMenuItem.Name = "rehberGörüsüToolStripMenuItem";
            this.rehberGörüsüToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.rehberGörüsüToolStripMenuItem.Text = "Rehber Görüsü";
            // 
            // rehbergörüsüToolStripMenuItem1
            // 
            this.rehbergörüsüToolStripMenuItem1.Name = "rehbergörüsüToolStripMenuItem1";
            this.rehbergörüsüToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.rehbergörüsüToolStripMenuItem1.Text = "rehbergörüsü";
            this.rehbergörüsüToolStripMenuItem1.Click += new System.EventHandler(this.rehbergörüsüToolStripMenuItem1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(356, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(356, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "label6";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button3.Location = new System.Drawing.Point(316, 160);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "Değiştir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // giristablo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(691, 331);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "giristablo";
            this.Text = "Anasayfa";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem yönetimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kullaniciİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eğitimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fakültelerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bölümlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem derslerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sınıfYönetimiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ogrencilerToolStripMenuItem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem okullarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem liseokulToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem liseokuldersleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ilkokulToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ilkokuldersleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notHesaplamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ogrenciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uninothesaplaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ortalamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem okulabaslamaayiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem okulabaslamaayiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dersnotlariToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dersnotlariToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rehberGörüsüToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rehbergörüsüToolStripMenuItem1;
    }
}

