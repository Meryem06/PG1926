﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;


namespace ogr_takip_portali
{
    public partial class giristablo : Form
    {
        public giristablo()
        {
            InitializeComponent();
        }
        MySqlConnection baglanti = new MySqlConnection("Server=localhost; Database=ogr_takip_portali; uid=root; Password= ;");
        DataTable tablo = new DataTable();
        private void yenile()
        {
                   
            MySqlCommand komut = new MySqlCommand("select * from giris");
           // MySqlCommand komut = new MySqlCommand( "select * from giris where id='" + textBox5.Text + "'");
            MySqlDataAdapter adaptor = new MySqlDataAdapter("select * from giris", baglanti);
            DataSet dsbilgiler = new DataSet();
            baglanti.Open();
            adaptor.Fill(dsbilgiler);
            baglanti.Close();
            dataGridView1.DataSource = dsbilgiler.Tables[0];
            
        }

        private void yetkikontrol()
        {

            try
            {
                MySqlCommand komut = new MySqlCommand("select * from giris where kullanici_adi='" + label5.Text + "' and sifre='" + MD5Sifrele(label6.Text) + "' ");

                MySqlDataAdapter adaptor = new MySqlDataAdapter("select * from giris;", baglanti);
                baglanti.Open();
                MySqlCommand komut1 = new MySqlCommand("select * from giris;", baglanti);
                MySqlDataReader yetki = komut.ExecuteReader();
                if (yetki.Read() == true)
                {

                    if (Convert.ToString(yetki[3]) == "yönetici")
                    {
                        kullaniciİşlemleriToolStripMenuItem.Enabled = true;


                    }
                    else if ((Convert.ToString(yetki[3]) == "sınırlı kullanıcı"))
                    {
                        kullaniciİşlemleriToolStripMenuItem.Enabled = false;
                    }

                }

                baglanti.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from giris", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        public static string MD5Sifrele(string metin)
        {
            try
            {
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

                byte[] btr = Encoding.UTF8.GetBytes(metin);
                btr = md5.ComputeHash(btr);
                StringBuilder sb = new StringBuilder();


                foreach (byte ba in btr)
                {
                    sb.Append(ba.ToString("x2").ToLower());

                }

                return sb.ToString();
            }
            catch (Exception)
            {

                throw;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut=new MySqlCommand("insert into giris(id,kullanici_adi,sifre,yetki) values ('"+textBox1.Text+ "','" + textBox2.Text +"','"+textBox3.Text+"','"+textBox4.Text+"')", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("başarılı");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from giris", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("delete from giris where id='"+textBox5.Text+"'",baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Silindi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from giris", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        public void textdoldur()
        {

            try
            {
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

            }
            catch
            {


            }

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            textdoldur();
        }
       private void button3_Click_1(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("update giris set id='" +textBox1.Text+ "',kullanici_adi='" +textBox2.Text+ "', sifre='" +textBox3.Text+ "', yetki='" +textBox4.Text+ "' where id='" +textBox5.Text+ "'",baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Değiştirildi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from giris;", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        
        private void button4_Click(object sender, EventArgs e)
        {
            yenile();
        }
              
        private void kullaniciİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            kullaniciislemleri kullaniciform = new kullaniciislemleri();
            this.Visible = false;

            kullaniciform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void fakültelerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fakulteler Fakulteform = new Fakulteler();
            this.Visible = false;

            Fakulteform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void bölümlerToolStripMenuItem_Click(object sender, EventArgs e)
        {
           Bolumler Bolumform = new Bolumler();
            this.Visible = false;

            Bolumform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void derslerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dersler Dersform = new Dersler();
            this.Visible = false;

            Dersform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void notlarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Notlar Notlarform = new Notlar();
            this.Visible = false;

           Notlarform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void ogrencilerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ogrenciler Ogrenciform = new ogrenciler();
            this.Visible = false;

            Ogrenciform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void liseokulToolStripMenuItem_Click(object sender, EventArgs e)
        {
            liseokul liseform = new liseokul();
            this.Visible = false;

            liseform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void liseokuldersleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            liseokuldersleri liseform = new liseokuldersleri();
            this.Visible = false;

            liseform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void ilkokulToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ilkokul ilkform = new ilkokul();
            this.Visible = false;

            ilkform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void ilkokuldersleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ilkokuldersleri ilkform = new ilkokuldersleri();
            this.Visible = false;

            ilkform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void ogrenciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ögrencinotuhesapla hesapform = new ögrencinotuhesapla();
            this.Visible = false;

            hesapform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void uninothesaplaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            üninothesaplama hesapform = new üninothesaplama();
            this.Visible = false;

            hesapform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void ortalamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ortalama hesapform = new ortalama();
            this.Visible = false;

            hesapform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        
    }

        private void okulabaslamaayiToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            okulabaslamaayi yashesapform = new okulabaslamaayi();
            this.Visible = false;

            yashesapform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

      

        private void dersnotlariToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            dersnotlari dersform = new dersnotlari();
            this.Visible = false;

            dersform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }

        private void rehbergörüsüToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            rehber_görüsü rehberform = new rehber_görüsü();
            this.Visible = false;

            rehberform.ShowDialog();
            this.Close();//not sayfa geçisi yapılıyor
        }
    }
    }
    

