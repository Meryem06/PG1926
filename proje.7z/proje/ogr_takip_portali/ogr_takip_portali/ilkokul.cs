﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace ogr_takip_portali
{
    public partial class ilkokul : Form
    {
        public ilkokul()
        {
            InitializeComponent();
        }
        MySqlConnection baglanti = new MySqlConnection("Server=localhost; Database=ogr_takip_portali; uid=root; Password= ;");
        DataTable tablo = new DataTable();
         private void ilkokul_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlDataAdapter adaptor = new MySqlDataAdapter("select * from ilkortaokul ", baglanti);
            adaptor.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("insert into ilkortaokul(ilkortano,ilkortaadi) values ('" + textBox1.Text + "','" + textBox2.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("başarılı");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from ilkortaokul ", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        public void textdoldur()
        {

            try
            {
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                
            }
            catch
            {


            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("delete from ilkortaokul where ilkortano='" + textBox3.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Silindi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from ilkortaokul ", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("update ilkortaokul set ilkortano='" + textBox1.Text + "',ilkortaadi='" + textBox2.Text + "' where ilkortano='" + textBox3.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Değiştirildi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from ilkortaokul", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            textdoldur();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            giristablo Girisform = new giristablo();
            this.Visible = false;

            Girisform.ShowDialog();
            this.Close();
        }
    }
}
