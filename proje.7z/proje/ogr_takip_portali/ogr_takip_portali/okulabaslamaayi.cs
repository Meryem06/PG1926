﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogr_takip_portali
{
    public partial class okulabaslamaayi : Form
    {
        public okulabaslamaayi()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ay;

            ay = int.Parse(textBox1.Text);

            if (ay < 60)
            {
                label2.Text = "okula gidemez";
            }
            else if (ay > 60 && ay < 66)
            {
                label2.Text = "isteğe bağlı";
            }
            else
            {
                label2.Text = "Zorunlu Gider";
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            giristablo Girisform = new giristablo();
            this.Visible = false;

            Girisform.ShowDialog();
            this.Close();
        }
    }
}
