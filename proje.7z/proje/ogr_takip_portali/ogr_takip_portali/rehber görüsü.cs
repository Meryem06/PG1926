﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogr_takip_portali
{
    public partial class rehber_görüsü : Form
    {
        public rehber_görüsü()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();//richtextbox1 deki metni kopyalar.
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();//richtextbox1 deki metni keser.
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();//richtextbox1 deki metni yapıştırır.
        }
        private bool kalin = false;//kalin isminde mantıksal değişken tanımlanıyor ilk değeri false
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (kalin == false)//eğer kalin değişkeni false ise
            {
                richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Bold);
                //richtextbox1 kontrolünde seçilen font yeni tanımlanan bold stiline dönüştürülüyor
                kalin = true;//seçilen metin bold olduğu için kalin değ. true yapılıyor
            }
            else
            {
                richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Regular);
                //richtextbox1 kontrolünde seçilen font normal stiline dönüştürülüyor
                kalin = false;//seçilen metin normale döndüğü için kalin değ. false yapılıyor
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Italic);//eğik
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Underline);
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Right;
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Center;
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Left;
        }

        private void toolStripButton10_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();//richtextbox1 deki metni keser.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            giristablo Girisform = new giristablo();
            this.Visible = false;

            Girisform.ShowDialog();
            this.Close();
        }
    }
}
