﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogr_takip_portali
{
    public partial class ögrencinotuhesapla : Form
    {
        public ögrencinotuhesapla()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int y1, y2, p;
            double sonuc;
            y1 = int.Parse(textBox1.Text);
            y2 = int.Parse(textBox2.Text);
            p = int.Parse(textBox3.Text);
            sonuc = (y1 + y2 + p) / 3;
            textBox4.Text = sonuc.ToString();
            if (sonuc >= 50)
            {
                label6.Text = "Geçtiniz";
            }
            else
            {
                label6.Text = "Kaldınız";
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            giristablo Girisform = new giristablo();
            this.Visible = false;

            Girisform.ShowDialog();
            this.Close();
        }
        MySqlConnection baglanti = new MySqlConnection("Server=localhost; Database=ogr_takip_portali; uid=root; Password= ;");
        DataTable tablo = new DataTable();
        private void button3_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            MySqlCommand komut = new MySqlCommand ("insert into ogrencinotuhesapla(ogrencino,Yazili1,Yazili2,Performans,Ortalama,Durum) values (" + textBox5.Text + "," + textBox1.Text + "," + textBox2.Text + "," + textBox3.Text + "," + textBox4.Text + ",'" + label6.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("başarılı");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from ogrencinotuhesapla", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
           baglanti.Close();
            

        }
        public void textdoldur()
        {

            try
            {
                textBox5.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                label6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            }
            catch
            {


            }

        }

        private void ögrencinotuhesapla_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlDataAdapter adaptor = new MySqlDataAdapter("select * from ogrencinotuhesapla ", baglanti);
            adaptor.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            textdoldur();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("delete from ogrencinotuhesapla where ogrencino='" + textBox6.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Silindi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from ogrencinotuhesapla ", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("update ogrencinotuhesapla set ogrencino='" + textBox5.Text + "',Yazili1='" + textBox1.Text + "', Yazili2='" + textBox2.Text + "',Performans='" + textBox3.Text + "',Ortalama='" + textBox4.Text + "',Durum='" + label6.Text + "'  where ogrencino='" + textBox6.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Değiştirildi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from ogrencinotuhesapla", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
    }
}
