﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ogr_takip_portali
{
    public partial class üninothesaplama : Form
    {
        public üninothesaplama()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double vize, final, ort;

            vize = double.Parse(textBox1.Text);
            final = double.Parse(textBox2.Text);

            ort = (vize * 40 / 100) + (final * 60 / 100);

            textBox3.Text = ort.ToString();
            if (ort >= 50)
            {
                textBox4.Text = "Geçti";
            }
            else
            {
                textBox4.Text = "Kaldı";
            }
                    }

        private void button2_Click(object sender, EventArgs e)
        {
            giristablo Girisform = new giristablo();
            this.Visible = false;

            Girisform.ShowDialog();
            this.Close();
        }
        MySqlConnection baglanti = new MySqlConnection("Server=localhost; Database=ogr_takip_portali; uid=root; Password= ;");
        DataTable tablo = new DataTable();
        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("insert into uninnothesapla(ogrencino,vize,final,ortalama,durum) values ('" + textBox5.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("başarılı");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from uninnothesapla", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
        public void textdoldur()
        {

            try
            {
                textBox5.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                           }
            catch
            {


            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("delete from uninnothesapla where ogrencino='" + textBox6.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Silindi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from uninnothesapla ", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void üninothesaplama_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlDataAdapter adaptor = new MySqlDataAdapter("select * from uninnothesapla ", baglanti);
            adaptor.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            textdoldur();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            MySqlCommand komut = new MySqlCommand("update uninnothesapla set ogrencino='" + textBox5.Text + "',vize='" + textBox1.Text + "', final='" + textBox2.Text + "',ortalama='" + textBox3.Text + "',durum='" + textBox4.Text + "'  where ogrencino='" + textBox6.Text + "'", baglanti);
            komut.ExecuteNonQuery();
            MessageBox.Show("Değiştirildi");
            tablo.Clear();
            MySqlDataAdapter adap = new MySqlDataAdapter("select * from uninnothesapla", baglanti);
            adap.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }
    }
}
